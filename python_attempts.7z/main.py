from pprint import pprint

import requests
import folium
import polyline

import json

from typing import Tuple


# {longitude},{latitude};{longitude},{latitude}[;{longitude},{latitude} ...]
class Calcer:
    bus_terminals = []
    airports = []
    roads = []
    railway_stations = []
    piers = []
    all_nodes = []

    def __init__(self):
        self.session = requests.Session()
        self.bus_terminals = self.get_nodes_from_elements(self.read_json_file('авто_вокзалы_волгограда.json'))
        self.airports = self.get_nodes_from_elements(self.read_json_file('аэропорты_волгограда.json'))
        self.roads = self.get_nodes_from_elements(self.read_json_file('дороги_волгограда.json'))
        self.railway_stations = self.get_nodes_from_elements(self.read_json_file('жд_вокзалы_волгограда.json'))
        self.piers = self.get_nodes_from_elements(self.read_json_file('речные_вокзалы_волгограда.json'))

        self.all_nodes = [
            *self.bus_terminals,
            *self.airports,
            *self.roads,
            *self.railway_stations,
            *self.piers
        ]

        for i in range(len(self.all_nodes)):
            for j in range(i + 1, len(self.all_nodes)):
                res = self.get_car_route(
                    (self.all_nodes[i]['lon'], self.all_nodes[i]['lat']),
                    (self.all_nodes[j]['lon'], self.all_nodes[j]['lat']),
                )
                pprint(res)
                exit(0)
                pass

        for node1 in self.all_nodes:
            for node2 in self.all_nodes:
                if node1 != node2:
                    pass

    @staticmethod
    def read_json_file(file_name: str):
        with open(file_name) as json_file:
            data = json.load(json_file)
        return data

    @staticmethod
    def get_nodes_from_elements(obj):
        nodes = []
        for element in obj['elements']:
            if element['type'] == 'node' \
                    and 'lat' in element \
                    and isinstance(element['lat'], float) \
                    and 'lon' in element \
                    and isinstance(element['lon'], float):
                nodes.append(element)
        return nodes

    def get_car_route(self, first_point: Tuple[float, float], second_point: Tuple[float, float]):
        p1_lon, p1_lat = first_point
        p2_lon, p2_lat = second_point
        url = f'http://localhost:5000/route/v1/car/{p1_lon},{p1_lat};{p2_lon},{p2_lat}?geometries=geojson'
        r = self.session.get(url)
        res = r.json()
        return res


Calcer()

# {'code': 'Ok', 'routes': [{'geometry': {'coordinates': [[44.513954, 48.712107], [44.513687, 48.711975], [44.513605, 48.711846], [44.51398, 48.711366], [44.511152, 48.70999], [44.510799, 48.709989], [44.50891, 48.711698], [44.51466, 48.71444], [44.517209, 48.715809], [44.516856, 48.716142], [44.516711, 48.716141], [44.516406, 48.715997]], 'type': 'LineString'}, 'legs': [{'steps': [], 'summary': '', 'weight': 207.1, 'duration': 207.1, 'distance': 1469.1}], 'weight_name': 'routability', 'weight': 207.1, 'duration': 207.1, 'distance': 1469.1}], 'waypoints': [{'hint': '80EFgP___385AAAAYwAAAL4AAAB5AAAA23bAQfp3ikHCPJ5C9sdKQjkAAABjAAAAvgAAAHkAAACBAAAAojqnAqtJ5wJGOKcC6EvnAgYAvw6e_7lN', 'distance': 77.685522006, 'name': '', 'location': [44.513954, 48.712107]}, {'hint': 'S1cFgP___38KAAAAkgAAAAAAAADTAAAAzUUVQP228EEAAAAAyzA8QgoAAACSAAAAAAAAANMAAACBAAAANkSnAt1Y5wICRacCIljnAgAArw6e_7lN', 'distance': 25.645915281, 'name': '', 'location': [44.516406, 48.715997]}]}
# routes = polyline.decode('uaihHecunGXr@XN~AiArGtP?dAuIxJcP}b@qG}NaAdA?\\Zz@')
# pprint(routes)
# def get_route(pickup_lon, pickup_lat, dropoff_lon, dropoff_lat):
#     loc = "{},{};{},{}".format(pickup_lon, pickup_lat, dropoff_lon, dropoff_lat)
#     url = "http://localhost:5000/route/v1/car/"
#     r = requests.get(url + loc)
#     if r.status_code != 200:
#         return {}
#     res = r.json()
#     routes = polyline.decode(res['routes'][0]['geometry'])
#     start_point = [res['waypoints'][0]['location'][1], res['waypoints'][0]['location'][0]]
#     end_point = [res['waypoints'][1]['location'][1], res['waypoints'][1]['location'][0]]
#     distance = res['routes'][0]['distance']
#     out = {
#         'start_point': start_point,
#         'end_point': end_point,
#         'distance': distance
#     }
#     return out
# pickup_lon, pickup_lat, dropoff_lon, dropoff_lat = 44.51335, 48.71268, 44.51661, 48.71581
# test_route = get_route(pickup_lon, pickup_lat, dropoff_lon, dropoff_lat)
# pprint(test_route)
