from pprint import pprint

import overpy

from query_strings import airports

api = overpy.Overpass()
r = api.query(airports)

coords = []
coords += [(float(node.lon), float(node.lat))
           for node in r.nodes]
coords += [(float(way.center_lon), float(way.center_lat))
           for way in r.ways]
coords += [(float(rel.center_lon), float(rel.center_lat))
           for rel in r.relations]


pprint(coords)